addpath('/Users/jxy198/mosek/7/toolbox/r2013a/');

global problemMap problemSet
problemMap = containers.Map('KeyType', 'char', 'ValueType', 'double');
problemSet = {};